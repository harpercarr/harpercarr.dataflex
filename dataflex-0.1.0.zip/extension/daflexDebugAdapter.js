const { DebugSession } = require('vscode-debugadapter');
const winax = require('winax');
const path = require('path');

class DataFlexDebugSession extends DebugSession {
    constructor() {
        super();
        this.debuggerEngine = new winax.Object('VDFDebugger.CDebuggerEngine');
        this.setDebuggerLinesStartAt1(true);
        this.setDebuggerColumnsStartAt1(true);
    }

    initializeRequest(response, args) {
        response.body = {
            supportsConfigurationDoneRequest: true,
            supportsSetBreakpointsRequest: true,
            supportsStepIn: true,
            supportsStepOut: true,
            supportsStepOver: true,
            supportsEvaluateForHovers: true
        };
        this.sendResponse(response);
    }

    launchRequest(response, args) {
        const program = args.program || 'path\\to\\default.exe';
        this.debuggerEngine.StartProgram(program, false);
        this.attachEvents();
        this.sendResponse(response);
        this.sendEvent(new Event('initialized'));
    }

    setBreakPointsRequest(response, args) {
        const file = args.source.path;
        const breakpoints = args.breakpoints || [];
        const setBreakpoints = [];

        for (const bp of breakpoints) {
            let line = bp.line;
            const success = this.debuggerEngine.SetBreakPoint(file, line);
            setBreakpoints.push({ verified: success, line });
        }

        response.body = { breakpoints: setBreakpoints };
        this.sendResponse(response);
    }

    pauseRequest(response) {
        this.debuggerEngine.Pause();
        this.sendResponse(response);
    }

    continueRequest(response) {
        this.debuggerEngine.Continue();
        this.sendResponse(response);
    }

    stepInRequest(response) {
        this.debuggerEngine.StepInto();
        this.sendResponse(response);
    }

    stepOverRequest(response) {
        this.debuggerEngine.StepOver();
        this.sendResponse(response);
    }

    stepOutRequest(response) {
        this.debuggerEngine.StepOut();
        this.sendResponse(response);
    }

    disconnectRequest(response) {
        this.debuggerEngine.StopProgram();
        this.sendResponse(response);
    }

    evaluateRequest(response, args) {
        const expr = args.expression;
        let result = '';
        const success = this.debuggerEngine.Eval(expr, result);
        response.body = {
            result: success ? result : 'Evaluation failed',
            variablesReference: 0
        };
        this.sendResponse(response);
    }

    attachEvents() {
        this.debuggerEngine.on('_IDebuggerEngineEvents.OnProgramPaused', (file, line, limitedBreakMode) => {
            this.sendEvent(new Event('stopped', { reason: 'pause', allThreadsStopped: true }));
        });

        this.debuggerEngine.on('_IDebuggerEngineEvents.OnProgramExit', () => {
            this.sendEvent(new Event('terminated'));
        });

        this.debuggerEngine.on('_IDebuggerEngineEvents.OnUpdateView', (file, line) => {
            this.sendEvent(new Event('stopped', { reason: 'breakpoint', allThreadsStopped: true }));
        });
    }

    // Add to class
    variablesRequest(response, args) {
        const variablesWindow = new winax.Object('VDFDebugger.CVariablesWindow');
        variablesWindow.WindowType = 0; // Local variables
        const variables = []; // Mock: fetch actual variables via COM if exposed
        response.body = { variables };
        this.sendResponse(response);
    }

    stackTraceRequest(response) {
        const callStack = new winax.Object('VDFDebugger.CCallStack');
        const frames = []; // Mock: fetch via GetAllMessages or similar if exposed
        response.body = { stackFrames: frames };
        this.sendResponse(response);
    }
}

DataFlexDebugSession.run(DataFlexDebugSession);